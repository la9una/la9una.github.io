

# Introducción a HTML 

Los documentos HTML están escritos en **texto plano**, pudiéndose crear un editor de texto como _notepad_ (en Windows). Sin embargo es recomendable emplear algún editor de texto específico para este propósito, ya que nos facilitará en gran medida la escritura de código. Por ejemplo, [Sublime Text](https://www.sublimetext.com/), [Notepad++](https://notepad-plus-plus.org/), [Visual Studio Code](https://code.visualstudio.com/) o [Brackets](http://brackets.io/), entre otros. 


**HTML es un lenguaje de marcado**. Es decir, a través de ciertas marcas o **etiquetas**, es posible indicar al navegador (Chrome, Firefox, Internet Explorer -Edge-, Opera, Safari, etc.) la estructura de una página. 

Los **nombres de las etiquetas**, pueden escribirse en mayúsculas o en minúsculas, sin embargo es recomendable escribirlas usando minúsculas. 

Una etiqueta, está contenida entre los signos de menor que (`<`) al comienzo y mayor que (`>`) al final. He aquí un ejemplo sencillo:

```hmtl
<p>Esto es texto dentro de un párrafo.</p>
```
En este ejemplo hay una etiqueta de comienzo y otra de cierre. Las etiquetas de cierre son las mismas que las etiquetas de comienzo sólo que contienen una barra justo después del signo menor que. 

>Muchos elementos de HTML se escriben empleando las dos etiquetas de comienzo y final. Sin embargo, ciertos elementos no necesitan etiquetas de cierre. 

#Descubriendo HTML
Nos introduciremos en el estudio de los fundamentos de HTML a través de ejercicios consistentes en **fragmentos de código los cuales deberás transcribir** (y no copiar y pegar) valiéndote de tu editor de texto favorito, cuidando de guardar cada archivo con la extensión `.html`. 

> Cada vez que quieras observar los resultados de tu trabajo, deberás abrir el archivo `.html` con tu navegador favorito. 



### Ejercicio1.html 
Abrí el editor de texto y transcribí el siguiente código: 

```html
<!DOCTYPE html>
<html>
    <head>
      <title>Ejercicio 1</title>
    </head>
    <body>
      Hola mundo!
    </body>
</html>
```

Guardalo con el nombre de `ejercicio1.html`. Luego, abrí el archivo con tu navegador y respondé las siguientes preguntas: 

1. ¿Qué es lo que ves en el cuerpo de la página? 
2. ¿Qué pasó con la leyenda "Ejercicio 1"?

Como podrás observar, lo que se visualiza en la página es aquello que se encuentra entre las etiquetas `<body></body>`. El texto que aparece en la barra de título de navegador es aquel que escribimos dentro de las etiquetas `<head></head` (particularmente de la etiqueta `<title></title>` que está ubicada dentro de la etiqueta `<head></head>`)

> En este ejercicio escribimos la estructura básica de un documento HTML. 

### Ejercicio2.html 
Este ejercicio consta de dos partes. En primer lugar, deberás copiar el siguiente código: 

```html
<!DOCTYPE html>
<html>
    <head>
      <title>Ejercicio 2</title>
    </head>
    <body>
      ¡Hola mundo! ¡Esta es mi segunda página!
    </body>
</html>
```
Guarda el archivo con el nombre `ejercicio2.html` y abrilo con el navegador: ¿Observás algo particular? 

Ahora, volvé a abrir el archivo con el editor de texto y agregá los siguientes fragmentos de código: 

```html
<!DOCTYPE html>
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 2</title>
    </head>
    <body>
      ¡Hola mundo! ¡Esta es mi segunda página!
    </body>
</html>
```
¿Ocurrió algún cambio?

Efectivamente, el **atributo** **_charset_** le indica al navegador el conjunto (o mapa) de caracteres que debe emplear para mostrar la página. En el ejemplo, **UTF-8** permite, entro otros, caracteres propios del idioma español, como como las eñes (ñÑ), signos de exclamación de apertura (¡), etc. Por otro lado, el **atributo _lang_** le indica al navegador que el idioma del documento será el español. 

### Ejercicio3.html 
Abrí el editor de texto y copiá el siguiente código: 

```html
<!DOCTYPE html>
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 3</title>
    </head>
    <body>
      <h1>Hola mundo!</h1>
      <h2>Hola mundo!</h2>
      <h3>Hola mundo!</h3>
      <h4>Hola mundo!</h4>
      <h5>Hola mundo!</h5>
      <h6>Hola mundo!</h6>
    </body>
</html>
```
Guarda el archivo con el nombre `ejercicio3.html` y abrilo con el navegador. 

¿Qué función cumplen las etiquetas `h1` a `h6`? 

### Ejercicio4.html 
Abrí el editor de texto y copiá el siguiente código: 

```html
<!DOCTYPE html>
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 4</title>
    </head>
    <body>
      Esta es una línea de texto. 

      Esta es otra línea de texto. ¿Se ubicará debajo de la primera?
    </body>
</html>
```
Guarda el archivo con el nombre `ejercicio4.html` y abrilo con el navegador. 

1. ¿Cómo se visualizan ambas líneas de texto?
2. Ahora, volvé a abrir el archivo con el editor de texto e ingresá entre ambas líneas de texto varios espacios en blanco (presionando la tecla Enter). Guardá el archivo y abrilo con el navegador ¿Ahora, como se visualizan las líneas de texto? ¿A qué conclusión llegás?
3. Por útimo, volvé a abrir el archivo con el editor de texto y escribí: 

```html
<!DOCTYPE html>
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 4</title>
    </head>
    <body>
        <p>Esta es una línea de texto.</p>
        <p>Esta es otra línea de texto. Se ubicará debajo de la primera?</p>
	</body>
</html>
```
4. ¿Observás algún cambio?

Como habrás podido observar, las línea inferior se muetra ahora en un "nuevo renglón". Esto fue posible gracias a la **etiqueta párrafo** (`<p></p>`) que encierra el texto de un párrafo determinado. 

### Ejercicio5.html

Abrí el editor de texto y copiá el siguiente código: 

```html
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 5</title>
    </head>
    <body>
		<ul>
    		<li>Cuaderno</li>
          	<li>Lapicera</li>
          	<li>Goma</li>
          	<li>Pendrive</li>
      	</ul>
      
      	<ol>
    		<li>Bebe</li>
          	<li>Niño</li>
          	<li>Adolescente</li>
          	<li>Joven</li>
      	</ol>
    </body>
</html>
```

Guarda el archivo con el nombre `ejercicio5.html` y abrilo con el navegador. 

1. ¿Qué estructura se visualiza en la página?
2. ¿Qué diferencia aparecen en ambas estructuras?

Acabá de crear listas. Éstas pueden ser de dos tipos: 

* Listas desordenadas `ul`(**U**nordered **L**ist ) 

* Listas ordenadas `ol` (**O**rdered **L**ist)

3. Intentá identificar cuáles son las listas ordenadas y cuáles las desordenadas. 

En ambos casos, la etiqueta `li` (**Li**st) indica los elemtos que conforman la lista. 

### Ejercicio6.html 
Abrí el editor de texto y transcribí el siguiente código: 

```html
<!DOCTYPE html>
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 6</title>
    </head>
    <body>
		Si hacés clic <a href="enlace.html">sobre este enlace</a> viajarás hacia otra dimesión. 
    </body>
</html>
```
Guarda el archivo con el nombre `ejercicio6.html`. Ahora, con el editor abierto, creá otro archivo con el siguiente contenido: 

```html
<!DOCTYPE html>
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 6</title>
    </head>
    <body>
    	<h3>Bienvenido</h3>
		Hola! Soy otra página. 
		Mejor vuelvo a <a  href="ejercicio6.html">la página anterior</a>. 		  Chau! 
    </body>
</html>
```
Guardalo con el nombre `enlace.html`.  Ahora abrí cualquiera de los dos documentos creados con el navegador. 

* Hacé clic sobre el texto color azul repetidas veces ¿Qué ocurre? 

Acabás de crear un enlace o _link_ que, en este caso, comunica dos documentos distintos. Para ello nos hemos valido de la etiqueta `<a></a>` donde en el **atributo href** hemos indicado la página a la cual queremos _que nos lleve el enlace_. 

* Cambiá el valor de `href` por una dirección web. Por ejemplo, `www.google.com`.  Guardá los cambios y abrí el documento con el navegador haciendo clic en el enlace ¿Qué ocurre?

### Ejercicio7.html 
Descargá la siguiente imagen: 

![](html5.png)

Luego, abrí el editor de texto y transcribí el siguiente código: 

```html
<!DOCTYPE html>
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 7</title>
    </head>
    <body>
    	<h3>Este es el ejercicio 7</h3>
		<img src="html5.png" /> 
    </body>
</html>
```

Guarda el archivo con el nombre `ejercicio7.html`. 

> Importante: deberás guardar la imagen en el mismo lugar que `ejercicio7.html`

* Abrí el docuemento con un navegador. ¿Qué observás?

Como habrás notado, la etiqueta `img` se emplea para vincular imágenes al documento. El **atributo src** se emplea para indicar el nombre (y eventualmente la ubicación) de la imagen. 

Si te fijaste bien, la etiqueta se _autocierra_ es decir, no posee una etiqueta para la apertura y otra para el cierre. 

Otra etiqueta que se _autocierra_ es `<br />` conocida como **_breaking rule_**.  Agregala en el documento anterior, según: 

```html
<!DOCTYPE html>
<html lang=es>
    <head>
      <meta charset="UTF-8">
      <title>Ejercicio 7</title>
    </head>
    <body>
    	<h3>Este es el ejercicio 7</h3>
    	<br />
    	<br />
    	<br />
    	<br />
    	<br />
		<img src="html5.png" /> 
    </body>
</html>
```

* Según tu parecer, ¿cuál es la función de la etiqueta `<br />`?