#1º Evaluación (modelo) 
![Cabecera](header_fisica.svg)

**1. Partiendo de un rectángulo de base  $b = 82 cm \pm 0,1 cm$ y altura $a = 35 cm \pm 0,1 cm$, calcular:**
a. Valor aproximado de la superficie
b. Error relativo
c. Error porcentual

**2. Realizadas varias mediciones de una longitud, surge que el valor más probable es 22 cm, con un error porcentual de 0,3%. Calcular:**
a. Error absoluto
b. Valor probable de la superficie

**3. Se conocen los siguientes datos de una sustancia: Masa $m = 760g\pm0,4g​$ y Volumen $v = 500cm^3\pm0,05cm^3​$. Calcular: **
a. Valor probable de la densidad
b. Error relativo

**4. Escribí las siguientes magnitudes sin emplear prefijos: **
a. $40\:\mu W$				
b. $4\:ns$				
c. $25\:km$		  	

**5. Expresar las siguientes magnitudes en notación científica: **
a. $1.000.000\:W$				
b. $0,002\:g$				
c. $30.000\:s$		  

**6. Resolvé: **
a. $1,2 x 10^6 \: kg + 3 x 10^5 \: kg$
b. $\frac {(3 x 10^4 \: kg) \cdot {4 x 10^4 \: m}} {6 x 10^{4} \: s }$
