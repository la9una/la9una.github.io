#Dimensiones de las magnitudes físicas 
![Cabecera](header_fisica.svg)

**1. Expresá las siguientes medidas en notación científica: **
a. $5.800 \:m$				e. $0,000508 \:kg$		i. $300.000.000 \:s$
b. $450.000 \:m$				f. $0,00000045 \:kg$		j. $186.000 \:s$
c. $302.000.000 \:m$		  	g. $0,003600 \:kg$		k. $93.000.000 \:s$
d. $86.000.000.000 \:m$		h. $0,00 \:kg$

**2. Convertí en metros cada una de las siguientes medidas de longitud: **
a. $1,1\: cm$			b. $76,2 \:pm$		c. $2,1 \:km$		d. $0,123 \:Mm$

**3. Convertí en kilogramos cada una de las siguientes medidas de masa: **
a. $127 \:g$				b. $11 \:\mu g$		$c. 7,23 \:Mg$		$d. 478 \:mg$

**4. Resolvé los siguientes problemas, expresando el resultado usando notación científica: **
a. $1,2 x 10^6 \: kg + 3 x 10^5 \: kg$ 					f. $(2 x 10^4 \: m) \cdot (4 x 10^8 \: m)$				k. $\frac {6 x 10^8 \: kg} {2 x 10^4 \: m^3}$

b. $2,26 x 10^{-18} \: m^2 - 1,80 x 10^{-18} \: m^2$ 		g. $(6 x 10^{-4} \: m) \cdot (5 x 10^{-8} \: m)$			l. $\frac {6 x 10^8 \: kg} {2 x 10^{-4} \: m^3 }$

c. $5,0 x 10^{-7} \: mg + 4 x 10^{-8} \: mg$				h. $(3 x 10^4 \: \: m) \cdot (2 x 10^6 \: m)$				ll. $\frac {6 x 10^{-8} \: kg} {2 x 10^{-4} \: m^3 }$

d. $8,2 \: km - 3 x 10^2 \: m$ 						i. $(2,5 x 10^{-7} \: m) \cdot (2,5 x 10^{16} \: m)$		m. $\frac {(3 x 10^4 \: kg) \cdot {4 x 10^4 \: m}} {6 x 10^{4} \: s }$

e. $1,66 x 10^{-19} \: kg + 2,30 x 10^{-19} \: kg$ 			j. $\frac {(2,5 x 10^6 \: kg) \cdot {6 x 10^4 \: m}} {5 x 10^{-2} \: s }$

**5. Encontrá el número de cifras significativas en cada una de las siguientes medidas: **

a. $2804 \: m$		d. $0,003068 \: m$		g. $75 \: m$				j. $1,87 x 10^6 \: ml$
b. $2,84 \: m$		e. $4,6 x 10^5 \: m$		h. $75,00 \: mm$			k. $1,008 x 10^8 \: m$
c. $0,0029 \: m$		f. $4,06 x 10^5 \: g$			i. $0,007060 \: kg$		l. $1,20 x 10^{-4} \: m$

**6. Resolvé las siguientes operaciones: **

a. $6,201 \: cm + 7,4 \: cm + 0,68 cm + 12,0 \: cm$				e. $3,2145 \: km \cdot 4,23 \: km$
b. $10,8 \: g - 8,264 \: g$									f. $20,2 \: cm \div 7,41 \: s$
c. $475 \: m - 0,4168 \: m$									g. $3,1416 \: cm \div 12,4 \: s$
d. $131 \: cm \cdot 2,3 \: cm$


